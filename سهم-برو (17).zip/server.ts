import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import dotenv from "dotenv";
import multer from "multer";
import fs from "fs";
import crypto from "crypto";

dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB limit
});

const PORT = 3000;

const MEGAVISION_API_KEY = process.env.MEGAVISION_API_KEY || "AIzaSyBgN87E6HQz0p-nv8FXfmafDT9fnpubA3Q";
const API_KEY = process.env.MARKET_DATA_API_KEY || "d6sjin9r01qj447bvi40d6sjin9r01qj447bvi4g";

const SYMBOL_MAP: Record<string, string> = {
  'EUR/USD': 'OANDA:EUR_USD',
  'GBP/USD': 'OANDA:GBP_USD',
  'USD/JPY': 'OANDA:USD_JPY',
  'AUD/USD': 'OANDA:AUD_USD',
  'USD/CHF': 'OANDA:USD_CHF',
  'Gold (XAU/USD)': 'OANDA:XAU_USD',
  'BTC/USD': 'BINANCE:BTCUSDT',
  'Oil (WTI)': 'OANDA:WTICO_USD',
};

const ICT_CONCEPTS = [
  'Market Structure Shift (MSS)',
  'Change of Character (CHoCH)',
  'Breaker Block Entry',
  'Mitigation Block',
  'Optimal Trade Entry (OTE)',
  'Silver Bullet Setup',
];

app.get("/api/recommendation", async (req, res) => {
  try {
    const symbols = Object.keys(SYMBOL_MAP);
    const randomSymbol = symbols[Math.floor(Math.random() * symbols.length)];
    const finnhubSymbol = SYMBOL_MAP[randomSymbol];

    // Fetch real price from Finnhub
    let currentPrice = 0;
    try {
      const response = await axios.get(`https://finnhub.io/api/v1/quote?symbol=${finnhubSymbol}&token=${API_KEY}`);
      currentPrice = response.data.c || 0;
    } catch (error) {
      console.error("Finnhub API error:", error);
    }

    // Fallback if price is 0 (API limit or error)
    if (currentPrice === 0) {
      if (randomSymbol.includes('JPY')) currentPrice = 140 + Math.random() * 10;
      else if (randomSymbol.includes('BTC')) currentPrice = 60000 + Math.random() * 5000;
      else if (randomSymbol.includes('Gold')) currentPrice = 2100 + Math.random() * 100;
      else if (randomSymbol.includes('Oil')) currentPrice = 70 + Math.random() * 10;
      else currentPrice = 0.6 + Math.random() * 0.7;
    }

    const type = Math.random() > 0.5 ? 'BUY' : 'SELL';
    const decimals = randomSymbol.includes('JPY') ? 3 : (randomSymbol.includes('BTC') || randomSymbol.includes('Gold') || randomSymbol.includes('Oil') ? 2 : 5);
    const pipValue = 1 / Math.pow(10, decimals - 1);
    const spread = 20 * pipValue;

    const recommendation = {
      symbol: randomSymbol,
      company: randomSymbol, // In App.tsx we map this to Arabic
      type,
      price: parseFloat(currentPrice.toFixed(decimals)),
      target: parseFloat((type === 'BUY' ? currentPrice + spread * 3 : currentPrice - spread * 3).toFixed(decimals)),
      stopLoss: parseFloat((type === 'BUY' ? currentPrice - spread * 2 : currentPrice + spread * 2).toFixed(decimals)),
      timestamp: new Date(),
      confidence: Math.floor(80 + Math.random() * 15),
      ictDetails: {
        concept: ICT_CONCEPTS[Math.floor(Math.random() * ICT_CONCEPTS.length)],
        fvg: (currentPrice + (type === 'BUY' ? -spread : spread)).toFixed(decimals),
        liquidity: (type === 'BUY' ? 'Sell-Side Liquidity (SSL) Swept' : 'Buy-Side Liquidity (BSL) Swept'),
        orderBlock: (currentPrice + (type === 'BUY' ? -spread * 0.5 : spread * 0.5)).toFixed(decimals),
      },
      isRealData: currentPrice > 0
    };

    res.json(recommendation);
  } catch (error) {
    res.status(500).json({ error: "Failed to generate recommendation" });
  }
});

// === Database & Free Trial Management Setup ===
const DB_FILE = path.join(process.cwd(), "db_store.json");

interface AccessCode {
  id: string;
  code: string;
  createdAt: string;
  status: "active" | "disabled";
  firstNetworkUsedBy?: string; // Binds to the first network/IP used
  deviceId?: string; // Binds to the first device ID
  isTrial?: boolean;
  expiresAt?: string;
  trialFingerprint?: string;
  trialIp?: string;
  maxUses?: number | null; // maximum uses per code
  usedCount?: number;      // how many times the code has been used
  redemptions?: {
    timestamp: string;
    ip: string;
    deviceId?: string;
    fingerprint?: string;
  }[];
}

interface TrialRecord {
  id: string;
  fingerprint: string;
  deviceId: string;
  ip: string;
  userAgent: string;
  createdAt: string;
  expiresAt: string;
  accessCode: string;
  status: "active" | "expired";
}

interface TrialLog {
  timestamp: string;
  event: "claim_success" | "claim_failed_abuse" | "claim_failed_banned" | "expired_cleanup" | "login_failed_banned" | "login_success" | "admin_cleared";
  ip: string;
  fingerprint: string;
  deviceId: string;
  details: string;
}

interface AuditLog {
  timestamp: string;
  event: string;
  ip: string;
  code: string;
  details: string;
}

interface DatabaseStore {
  accessCodes: AccessCode[];
  bannedClients: string[]; // Device IP or fingerprint/deviceId identifiers
  trialActivations?: Record<string, number>; // Legacy mapping for backward compatibility
  trials?: TrialRecord[];
  trialLogs?: TrialLog[];
  auditLogs?: AuditLog[];
}

let memoDb: DatabaseStore | null = null;

function getDB(): DatabaseStore {
  if (memoDb) {
    return memoDb;
  }
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(data);
      if (!parsed.accessCodes) parsed.accessCodes = [];
      if (!parsed.bannedClients) parsed.bannedClients = [];
      if (!parsed.trials) parsed.trials = [];
      if (!parsed.trialLogs) parsed.trialLogs = [];
      if (!parsed.auditLogs) parsed.auditLogs = [];
      memoDb = parsed;
      return memoDb!;
    }
  } catch (e) {
    console.error("Error reading database file, resetting...", e);
  }
  const defaultDB: DatabaseStore = { accessCodes: [], bannedClients: [], trials: [], trialLogs: [], auditLogs: [] };
  saveDB(defaultDB);
  memoDb = defaultDB;
  return memoDb;
}

function saveDB(db: DatabaseStore) {
  memoDb = db;
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (e) {
    console.error("Error saving database file, falling back to memory only:", e);
  }
}

function logAudit(db: DatabaseStore, event: string, ip: string, code: string, details: string) {
  if (!db.auditLogs) {
    db.auditLogs = [];
  }
  db.auditLogs.unshift({
    timestamp: new Date().toISOString(),
    event,
    ip,
    code,
    details
  });
}

// Generate secure cryptographically random access code
function generateSecureCode(length = 26): string {
  try {
    const lettersUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lettersLower = "abcdefghijklmnopqrstuvwxyz";
    const numbers = "0123456789";
    const specials = "!@#$%^&*()_+{}[]";
    const allChars = lettersUpper + lettersLower + numbers + specials;
    
    let result = "";
    const getRandomByte = (): number => {
      try {
        return crypto.randomBytes(1)[0];
      } catch (e) {
        return Math.floor(Math.random() * 256);
      }
    };

    result += lettersUpper[getRandomByte() % lettersUpper.length];
    result += lettersLower[getRandomByte() % lettersLower.length];
    result += numbers[getRandomByte() % numbers.length];
    result += specials[getRandomByte() % specials.length];

    while (result.length < length) {
      const idx = getRandomByte() % allChars.length;
      result += allChars[idx];
    }

    return result.split("").sort(() => getRandomByte() - 128).join("");
  } catch (error) {
    return "SAHM-" + Math.random().toString(36).substring(2, 15).toUpperCase();
  }
}

// Access code validation middleware (performs real server-side validation against expiration and bans)
const validateAccessCode = (req: any, res: any, next: any) => {
  const code = req.header("X-Access-Code") || req.query.code;
  const deviceId = req.header("X-Device-Id") || req.query.deviceId;
  
  if (!code) {
    return res.status(401).json({ error: "الرجاء إدخال رمز الوصول لتخطي جدار الحماية للذكاء الاصطناعي." });
  }

  // Root owner override
  if (code === "ONER+AA_IS") {
    return next();
  }

  const db = getDB();
  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

  // Enforce security ban checking on each request
  if (db.bannedClients.includes(clientIp) || (deviceId && db.bannedClients.includes(deviceId))) {
    return res.status(403).json({ error: "عذراً، هذا الجهاز وعنوان الإنترنت الخاص بك خاضعان لقرار حظر أمني نشط بسبب انتهاء فترة تجربة ومراجعة الموقع." });
  }

  const matching = db.accessCodes.find(c => c.code === code);
  if (!matching) {
    return res.status(401).json({ error: "رمز الوصول هذا غير صالح أو تم حذفه من قِبل المدير." });
  }

  if (matching.status === "disabled") {
    return res.status(403).json({ error: "عذراً، هذا الترخيص قد انتهى أو تم تعطيله." });
  }

  // General code - evaluate expiration on the fly
  if (!matching.isTrial && matching.expiresAt) {
    const expiresAtMs = new Date(matching.expiresAt).getTime();
    if (Date.now() > expiresAtMs) {
      matching.status = "disabled";
      logAudit(db, "validation_failed_expired", clientIp, code, `Attempted use of expired invitation code: ${code}`);
      saveDB(db);
      return res.status(403).json({ error: "عذراً، لقد انتهت صلاحية هذا الكود لتجاوز التاريخ المسموح به للصلاحية." });
    }
  }

  // General code - evaluate max usages
  if (!matching.isTrial && matching.maxUses !== undefined && matching.maxUses !== null) {
    const fingerprint = req.header("X-Fingerprint") || req.query.fingerprint;
    const currentRedemptions = matching.redemptions || [];
    const isAlreadyRedeemed = currentRedemptions.some(r => 
      (deviceId && r.deviceId === deviceId) || 
      (fingerprint && r.fingerprint === fingerprint)
    );

    if (!isAlreadyRedeemed && (matching.usedCount || 0) >= matching.maxUses) {
      logAudit(db, "validation_failed_overused", clientIp, code, `Attempted use of overused invitation code: ${code} (Usage: ${matching.usedCount}/${matching.maxUses})`);
      return res.status(403).json({ error: "عذراً، هذا الرمز استنفد كامل الفرص المسموح بها للاستخدام على الأجهزة." });
    }
  }

  // If trial code, evaluate expiration on the fly
  if (matching.isTrial && matching.expiresAt) {
    const expiresAtMs = new Date(matching.expiresAt).getTime();
    if (Date.now() > expiresAtMs) {
      // Auto-expire
      matching.status = "disabled";
      
      const tr = db.trials?.find(t => t.accessCode === code);
      if (tr) {
        tr.status = "expired";
      }

      // Automatically ban hardware to defend against bypass
      if (matching.deviceId && !db.bannedClients.includes(matching.deviceId)) {
        db.bannedClients.push(matching.deviceId);
      }
      if (matching.trialFingerprint && !db.bannedClients.includes(matching.trialFingerprint)) {
        db.bannedClients.push(matching.trialFingerprint);
      }
      if (clientIp && !db.bannedClients.includes(clientIp)) {
        db.bannedClients.push(clientIp);
      }

      if (!db.trialLogs) db.trialLogs = [];
      db.trialLogs.push({
        timestamp: new Date().toISOString(),
        event: "expired_cleanup",
        ip: clientIp,
        fingerprint: matching.trialFingerprint || "",
        deviceId: matching.deviceId || deviceId || "",
        details: `Auto-disabled code ${code} as 3-hour period expired.`
      });

      saveDB(db);
      return res.status(403).json({ error: "عذراً، لقد انتهت صلاحية حسابك التجريبي (3 ساعات) ولا يمكن استخدامه مرة أخرى." });
    }

    // Verify sharing constraint: ensure the current deviceId matches the registrant deviceId
    if (deviceId && matching.deviceId && deviceId !== matching.deviceId) {
      if (!db.trialLogs) db.trialLogs = [];
      db.trialLogs.push({
        timestamp: new Date().toISOString(),
        event: "login_failed_banned",
        ip: clientIp,
        fingerprint: matching.trialFingerprint || "",
        deviceId,
        details: `Access code ${code} sharing attempt from device ${deviceId}. Blocked.`
      });

      // Ban sharing offender device
      if (!db.bannedClients.includes(deviceId)) {
        db.bannedClients.push(deviceId);
      }
      saveDB(db);

      return res.status(403).json({ error: "عذراً، لا يمكن استخدام الرمز التجريبي على أكثر من جهاز واحد." });
    }
  }

  next();
};

// Secured Image Analysis Route
app.post("/api/analyze", validateAccessCode, upload.single('image'), async (req: any, res: any) => {
  try {
    let imageUrl = req.body.image_url;

    if (req.file) {
      const base64 = req.file.buffer.toString('base64');
      imageUrl = `data:${req.file.mimetype};base64,${base64}`;
    }

    if (!imageUrl) {
      imageUrl = "https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg";
    }

    const response = await axios.post("https://api.megavision.ai/analyze", 
      { image_url: imageUrl },
      {
        headers: {
          "Authorization": `Bearer ${MEGAVISION_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    res.json(response.data);
  } catch (error: any) {
    console.error("MegaVision API error:", error.response?.data || error.message);
    res.status(error.response?.status || 500).json(error.response?.data || { error: "Failed to analyze image" });
  }
});

// Authentication Access Portal
app.post("/api/auth/login", (req, res) => {
  const { password, localBan, userAgent, deviceId, fingerprint } = req.body;
  const db = getDB();

  // Root owner override
  if (password === "ONER+AA_IS") {
    return res.json({ success: true, role: "admin" });
  }

  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const banIdentifier = userAgent || clientIp || "unknown";

  // Check bans
  if (localBan === "true" || 
      (deviceId && db.bannedClients.includes(deviceId)) || 
      db.bannedClients.includes(banIdentifier) || 
      db.bannedClients.includes(userAgent || "")) {
    return res.status(403).json({ 
      error: "عذراً، هذا الجهاز وعنوان الإنترنت الخاص بك خاضعان لقرار حظر أمني نشط بسبب انتهاء فترة تجربة ومراجعة الموقع." 
    });
  }

  // Validate Code
  const matchingIndex = db.accessCodes.findIndex(c => c.code === password);
  if (matchingIndex !== -1) {
    const matching = db.accessCodes[matchingIndex];
    
    // Check if disabled
    if (matching.status === "disabled") {
      logAudit(db, "login_failed_disabled", clientIp, password, "Attempted login with a disabled or expired code.");
      saveDB(db);
      return res.status(403).json({ error: "عذراً، هذا الكود تم تعطيله وإيقافه مؤقتاً من قِبل مدير المنصة أو انتهت صلاحيته." });
    }

    // Evaluate trial code constraints on login
    if (matching.isTrial && matching.expiresAt) {
      const expiresAtMs = new Date(matching.expiresAt).getTime();
      
      if (Date.now() > expiresAtMs) {
        matching.status = "disabled";
        const tr = db.trials?.find(t => t.accessCode === password);
        if (tr) tr.status = "expired";

        // Hard lock to prevent bypasses
        if (matching.deviceId && !db.bannedClients.includes(matching.deviceId)) {
          db.bannedClients.push(matching.deviceId);
        }
        if (matching.trialFingerprint && !db.bannedClients.includes(matching.trialFingerprint)) {
          db.bannedClients.push(matching.trialFingerprint);
        }
        if (clientIp && !db.bannedClients.includes(clientIp)) {
          db.bannedClients.push(clientIp);
        }

        if (!db.trialLogs) db.trialLogs = [];
        db.trialLogs.push({
          timestamp: new Date().toISOString(),
          event: "expired_cleanup",
          ip: clientIp,
          fingerprint: matching.trialFingerprint || fingerprint || "",
          deviceId: matching.deviceId || deviceId || "",
          details: `Rejected login - Trial expired: ${password}`
        });

        logAudit(db, "login_failed_expired_trial", clientIp, password, "Trial period expired and device blacklisted.");
        saveDB(db);

        return res.status(403).json({ 
          error: "عذراً، لقد انتهت صلاحية حسابك التجريبي (3 ساعات) بالكامل لهذا الجهاز ولا يمكن استخدامه مرة أخرى.",
          triggerBan: true 
        });
      }

      // Check device ID sharing constraint
      if (deviceId && matching.deviceId && deviceId !== matching.deviceId) {
        if (!db.trialLogs) db.trialLogs = [];
        db.trialLogs.push({
          timestamp: new Date().toISOString(),
          event: "login_failed_banned",
          ip: clientIp,
          fingerprint: matching.trialFingerprint || fingerprint || "",
          deviceId,
          details: `Blocked login of trial code ${password} on different device (Owned: ${matching.deviceId}, Attempted: ${deviceId}).`
        });

        if (!db.bannedClients.includes(deviceId)) {
          db.bannedClients.push(deviceId);
        }
        logAudit(db, "login_failed_sharing_violation", clientIp, password, "Blocked trial sharing between different physical nodes.");
        saveDB(db);

        return res.status(403).json({ 
          error: "عذراً، لا يمكن استخدام الرمز التجريبي على أكثر من جهاز واحد.",
          triggerBan: true 
        });
      }

      const remainingSec = Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000));
      logAudit(db, "login_success_trial", clientIp, password, `Successful login to trial workspace with ${remainingSec}s remaining.`);
      saveDB(db);
      return res.json({ success: true, role: "trial", timeLeftSec: remainingSec, code: matching.code });
    } else {
      // General invitation / access code
      if (matching.expiresAt) {
        const expiresAtMs = new Date(matching.expiresAt).getTime();
        if (Date.now() > expiresAtMs) {
          matching.status = "disabled";
          logAudit(db, "login_failed_expired", clientIp, password, `Expired code login attempt (Expired: ${matching.expiresAt})`);
          saveDB(db);
          return res.status(403).json({ error: "عذراً، هذا الرمز قد انتهت صلاحيته الزمنيّة الفعّالة." });
        }
      }

      // Check redemptions list to identify whether this is a new or repeat device
      const currentRedemptions = matching.redemptions || [];
      const isAlreadyRedeemed = currentRedemptions.some(r => 
        (deviceId && r.deviceId === deviceId) || 
        (fingerprint && r.fingerprint === fingerprint)
      );

      if (!isAlreadyRedeemed) {
        if (matching.maxUses !== undefined && matching.maxUses !== null) {
          const used = matching.usedCount || 0;
          if (used >= matching.maxUses) {
            logAudit(db, "login_failed_overused", clientIp, password, `Redemption failed: Usage quota is full (${used}/${matching.maxUses})`);
            return res.status(403).json({ error: "عذراً، هذا الكود استنفد الحد الأقصى للأجهزة المسموح بها والمبرمجة." });
          }
        }

        // Safe to enroll new redemption node
        if (!matching.redemptions) matching.redemptions = [];
        matching.redemptions.push({
          timestamp: new Date().toISOString(),
          ip: clientIp,
          deviceId: deviceId || "unknown",
          fingerprint: fingerprint || "unknown"
        });
        matching.usedCount = (matching.usedCount || 0) + 1;
        logAudit(db, "login_redeem_success", clientIp, password, `Redeemed invitation code (New device enrolled: ${deviceId || 'unknown'}). Total: ${matching.usedCount}`);
        saveDB(db);
      } else {
        // Pre-enrolled node
        logAudit(db, "login_success_regular", clientIp, password, `Regular login with pre-enrolled device: ${deviceId}`);
        saveDB(db);
      }

      return res.json({ success: true, role: "regular", code: matching.code });
    }
  }

  logAudit(db, "login_failed_invalid_code", clientIp, password || "none", "Failed login attempt with unrecognized code credentials.");
  saveDB(db);
  return res.status(401).json({ error: "الرمز السري أو كود الوصول غير صالح. يرجى التأكد من الرمز والمحاولة مجدداً." });
});

// Trial Claim Endpoint: Claim free trial once per lifetime per device with advanced fingerprinting
app.post("/api/trial/claim", (req, res) => {
  const { fingerprint, deviceId } = req.body;
  const db = getDB();

  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const userAgent = req.get('User-Agent') || 'unknown';

  if (!fingerprint || !deviceId) {
    return res.status(400).json({ error: "بيانات البصمة الرقمية أو معرف العداد ناقصة." });
  }

  // Block if device/IP is in banned list
  if (db.bannedClients.includes(deviceId) || db.bannedClients.includes(fingerprint) || db.bannedClients.includes(clientIp)) {
    if (!db.trialLogs) db.trialLogs = [];
    db.trialLogs.push({
      timestamp: new Date().toISOString(),
      event: "claim_failed_banned",
      ip: clientIp,
      fingerprint,
      deviceId,
      details: "Claim blocked: Device ID, Fingerprint or IP is blacklisted."
    });
    saveDB(db);
    return res.status(403).json({ error: "عذراً، هذا الجهاز وعنوان الإنترنت الخاص بك خاضعان لقرار حظر أمني نشط بسبب انتهاء فترة تجربة ومراجعة الموقع." });
  }

  // Lookup existing claims to prevent abuse
  const existingByDevId = db.trials?.find(t => t.deviceId === deviceId);
  const existingByFP = db.trials?.find(t => t.fingerprint === fingerprint);
  const claimsByIp = db.trials?.filter(t => t.ip === clientIp).length || 0;

  if (existingByDevId || existingByFP || claimsByIp >= 2) {
    if (!db.trialLogs) db.trialLogs = [];
    
    let reason = "Free trial already used on this device.";
    let arbReason = "عذراً، تم استخدام التجربة المجانية بالفعل على هذا الجهاز.";
    if (claimsByIp >= 2) {
      reason = `IP limit reached (2 claims from ${clientIp})`;
      arbReason = "تم تجاوز الحد الأقصى للتجربة المجانية المخصصة لعنوان الإنترنت هذا (المنزل/الشبكة).";
    }

    db.trialLogs.push({
      timestamp: new Date().toISOString(),
      event: "claim_failed_abuse",
      ip: clientIp,
      fingerprint,
      deviceId,
      details: `Blocked activation request. Reason: ${reason}`
    });

    // Ban client parameters immediately on abusive claim attempts to prevent client-side bypass attempts
    if (deviceId && !db.bannedClients.includes(deviceId)) db.bannedClients.push(deviceId);
    if (fingerprint && !db.bannedClients.includes(fingerprint)) db.bannedClients.push(fingerprint);

    saveDB(db);
    return res.status(400).json({ error: arbReason });
  }

  // Safe to activate! Generate secure unique access code
  let code = "";
  let attempts = 0;
  while (attempts < 100) {
    code = generateSecureCode(26);
    if (!db.accessCodes.some(c => c.code === code)) {
      break;
    }
    attempts++;
  }

  const createdAt = new Date().toISOString();
  const expiresAt = new Date(Date.now() + 3 * 3600 * 1000).toISOString(); // exactly 3 hours

  // Insert AccessCode
  const codeId = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : crypto.randomBytes(16).toString("hex");
  const newCode: AccessCode = {
    id: codeId,
    code,
    createdAt,
    status: "active",
    isTrial: true,
    expiresAt,
    trialFingerprint: fingerprint,
    trialIp: clientIp,
    deviceId
  };

  db.accessCodes.unshift(newCode);

  // Add trial records
  const trialRecord: TrialRecord = {
    id: typeof crypto.randomUUID === "function" ? crypto.randomUUID() : crypto.randomBytes(16).toString("hex"),
    fingerprint,
    deviceId,
    ip: clientIp,
    userAgent,
    createdAt,
    expiresAt,
    accessCode: code,
    status: "active"
  };

  if (!db.trials) db.trials = [];
  db.trials.unshift(trialRecord);

  // Success Log
  if (!db.trialLogs) db.trialLogs = [];
  db.trialLogs.unshift({
    timestamp: createdAt,
    event: "claim_success",
    ip: clientIp,
    fingerprint,
    deviceId,
    details: `Trial generated and assigned: ${code}`
  });

  saveDB(db);

  res.status(201).json({
    success: true,
    code,
    expiresAt,
    timeLeftSec: 10800
  });
});

// Sync Status of current trial / code
app.get("/api/trial/status", (req, res) => {
  const code = req.query.code as string;
  const deviceId = req.query.deviceId as string;
  const db = getDB();

  if (!code) {
    return res.status(400).json({ error: "الرمز السري مفقود." });
  }

  const matching = db.accessCodes.find(c => c.code === code);
  if (!matching) {
    return res.json({ status: "invalid" });
  }

  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  if (db.bannedClients.includes(clientIp) || (deviceId && db.bannedClients.includes(deviceId)) || (matching.deviceId && db.bannedClients.includes(matching.deviceId))) {
    return res.json({ status: "banned" });
  }

  if (matching.status === "disabled") {
    return res.json({ status: "expired" });
  }

  if (matching.isTrial && matching.expiresAt) {
    const expiresAtMs = new Date(matching.expiresAt).getTime();
    const remainingSec = Math.max(0, Math.floor((expiresAtMs - Date.now()) / 1000));
    
    if (remainingSec <= 0) {
      // Auto-expire!
      matching.status = "disabled";
      const tr = db.trials?.find(t => t.accessCode === code);
      if (tr) tr.status = "expired";

      if (matching.deviceId && !db.bannedClients.includes(matching.deviceId)) {
        db.bannedClients.push(matching.deviceId);
      }
      if (matching.trialFingerprint && !db.bannedClients.includes(matching.trialFingerprint)) {
        db.bannedClients.push(matching.trialFingerprint);
      }
      if (clientIp && !db.bannedClients.includes(clientIp)) {
        db.bannedClients.push(clientIp);
      }

      if (!db.trialLogs) db.trialLogs = [];
      db.trialLogs.push({
        timestamp: new Date().toISOString(),
        event: "expired_cleanup",
        ip: clientIp,
        fingerprint: matching.trialFingerprint || "",
        deviceId: matching.deviceId || deviceId || "",
        details: `Access code ${code} expired during status ping.`
      });

      saveDB(db);
      return res.json({ status: "expired", timeLeftSec: 0 });
    }

    return res.json({ status: "active", timeLeftSec: remainingSec, isTrial: true });
  }

  return res.json({ status: "active", isTrial: false });
});

// Admin listings
app.get("/api/admin/trials", (req, res) => {
  const db = getDB();
  res.json(db.trials || []);
});

app.get("/api/admin/trial-logs", (req, res) => {
  const db = getDB();
  res.json(db.trialLogs || []);
});

// Admin code management APIs
app.get("/api/admin/codes", (req, res) => {
  const db = getDB();
  res.json(db.accessCodes);
});

app.get("/api/admin/audit-logs", (req, res) => {
  const db = getDB();
  res.json(db.auditLogs || []);
});

app.post("/api/admin/codes/generate", (req, res) => {
  const { expiresAt, maxUses } = req.body;
  const db = getDB();
  
  let attempts = 0;
  let code = "";
  while (attempts < 100) {
    code = generateSecureCode(26);
    if (!db.accessCodes.some(c => c.code === code)) {
      break;
    }
    attempts++;
  }

  const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

  const parsedMaxUses = maxUses !== undefined && maxUses !== "" && maxUses !== null ? parseInt(maxUses, 10) : null;

  const newCode: AccessCode = {
    id: typeof crypto.randomUUID === "function" ? crypto.randomUUID() : crypto.randomBytes(16).toString("hex"),
    code,
    createdAt: new Date().toISOString(),
    status: "active",
    expiresAt: expiresAt || undefined,
    maxUses: (parsedMaxUses !== null && !isNaN(parsedMaxUses)) ? parsedMaxUses : undefined,
    usedCount: 0,
    redemptions: []
  };

  db.accessCodes.unshift(newCode);
  logAudit(
    db, 
    "code_create", 
    clientIp, 
    code, 
    `Generated custom secure code. Max Uses: ${newCode.maxUses ?? 'Unlimited'}, Expires At: ${newCode.expiresAt ?? 'Never'}`
  );
  saveDB(db);
  res.status(201).json(newCode);
});

app.post("/api/admin/codes/toggle", (req, res) => {
  const { id } = req.body;
  const db = getDB();
  const index = db.accessCodes.findIndex(c => c.id === id);
  if (index !== -1) {
    const codeObj = db.accessCodes[index];
    codeObj.status = codeObj.status === "active" ? "disabled" : "active";
    const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    logAudit(db, "code_toggle", clientIp, codeObj.code, `Toggled active status. Code is now: ${codeObj.status}`);
    saveDB(db);
    return res.json({ success: true, item: codeObj });
  }
  res.status(404).json({ error: "Access Code not found" });
});

app.post("/api/admin/codes/delete", (req, res) => {
  const { id } = req.body;
  const db = getDB();
  const index = db.accessCodes.findIndex(c => c.id === id);
  if (index !== -1) {
    const codeObj = db.accessCodes[index];
    const clientIp = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    logAudit(db, "code_revoke", clientIp, codeObj.code, `Revoked and deleted code: ${codeObj.code}`);
    db.accessCodes.splice(index, 1);
    saveDB(db);
    return res.json({ success: true });
  }
  res.status(404).json({ error: "Access Code not found" });
});

app.get("/api/admin/bans", (req, res) => {
  const db = getDB();
  res.json(db.bannedClients);
});

app.post("/api/admin/bans/add", (req, res) => {
  const { fingerprint } = req.body;
  const db = getDB();
  if (fingerprint && !db.bannedClients.includes(fingerprint)) {
    db.bannedClients.push(fingerprint);
    saveDB(db);
  }
  res.json({ success: true });
});

app.post("/api/admin/bans/clear", (req, res) => {
  const db = getDB();
  db.bannedClients = [];
  db.trials = [];
  db.trialLogs = [];
  db.accessCodes = db.accessCodes.filter(c => !c.isTrial);
  if (!db.trialLogs) db.trialLogs = [];
  db.trialLogs.push({
    timestamp: new Date().toISOString(),
    event: "admin_cleared",
    ip: "admin",
    fingerprint: "admin",
    deviceId: "admin",
    details: "Admin cleared all bans, trials, logs, and trial codes cleanly."
  });
  saveDB(db);
  res.json({ success: true });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
