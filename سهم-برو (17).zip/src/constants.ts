import { Category, Restaurant, MenuItem } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'برجر', icon: '🍔' },
  { id: '2', name: 'بيتزا', icon: '🍕' },
  { id: '3', name: 'شاورما', icon: '🌯' },
  { id: '4', name: 'سوشي', icon: '🍣' },
  { id: '5', name: 'حلويات', icon: '🍰' },
  { id: '6', name: 'قهوة', icon: '☕' },
];

export const RESTAURANTS: Restaurant[] = [
  {
    id: 'r1',
    name: 'برجر هاوس',
    image: 'https://picsum.photos/seed/burger1/600/400',
    rating: 4.8,
    deliveryTime: '20-30 دقيقة',
    deliveryFee: 'مجاني',
    categories: ['برجر', 'وجبات سريعة'],
    isPopular: true,
  },
  {
    id: 'r2',
    name: 'بيتزا إيطاليانو',
    image: 'https://picsum.photos/seed/pizza1/600/400',
    rating: 4.5,
    deliveryTime: '30-45 دقيقة',
    deliveryFee: '5 ريال',
    categories: ['بيتزا', 'إيطالي'],
  },
  {
    id: 'r3',
    name: 'شاورما المعلم',
    image: 'https://picsum.photos/seed/shawarma1/600/400',
    rating: 4.9,
    deliveryTime: '15-25 دقيقة',
    deliveryFee: '3 ريال',
    categories: ['شاورما', 'عربي'],
    isPopular: true,
  },
  {
    id: 'r4',
    name: 'سوشي زون',
    image: 'https://picsum.photos/seed/sushi1/600/400',
    rating: 4.7,
    deliveryTime: '40-55 دقيقة',
    deliveryFee: '10 ريال',
    categories: ['سوشي', 'آسيوي'],
  },
];

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'm1',
    restaurantId: 'r1',
    name: 'كلاسيك برجر',
    description: 'لحم بقري مشوي مع خس، طماطم، وجبنة شيدر',
    price: 35,
    image: 'https://picsum.photos/seed/mburger1/400/300',
  },
  {
    id: 'm2',
    restaurantId: 'r1',
    name: 'تشيز برجر مضاعف',
    description: 'قطعتين لحم بقري مع طبقتين من الجبن',
    price: 45,
    image: 'https://picsum.photos/seed/mburger2/400/300',
  },
  {
    id: 'm3',
    restaurantId: 'r2',
    name: 'بيتزا مارغريتا',
    description: 'صلصة طماطم، موزاريلا، وريحان طازج',
    price: 40,
    image: 'https://picsum.photos/seed/mpizza1/400/300',
  },
];
