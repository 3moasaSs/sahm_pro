/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Clock, 
  Zap,
  ShieldCheck, 
  BarChart3, 
  AlertCircle,
  RefreshCw,
  Upload,
  FileSearch,
  CheckCircle2,
  MessageSquare,
  Send,
  User,
  Bot,
  Copy,
  Trash2,
  Key,
  Lock,
  Unlock,
  Ban,
  LogOut,
  Sparkles,
  History
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";
import Groq from "groq-sdk";
import ReactMarkdown from 'react-markdown';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem('sahm_logged_in') === 'true');
  const [userRole, setUserRole] = useState<'admin' | 'regular' | 'trial' | null>(() => localStorage.getItem('sahm_user_role') as any || null);
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  
  // Custom access codes dashboard states
  const [accessCodes, setAccessCodes] = useState<{ 
    id: string; 
    code: string; 
    createdAt: string; 
    status: 'active' | 'disabled';
    expiresAt?: string | null;
    maxUses?: number | null;
    usedCount?: number;
    redemptions?: { timestamp: string; ip: string; deviceId?: string; fingerprint?: string }[];
  }[]>([]);
  const [generationExpiresAt, setGenerationExpiresAt] = useState('');
  const [generationMaxUses, setGenerationMaxUses] = useState('');
  const [auditLogs, setAuditLogs] = useState<{ timestamp: string; event: string; ip: string; code: string; details: string }[]>([]);
  const [isAdminLoading, setIsAdminLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Device ban status
  const [isDeviceBanned, setIsDeviceBanned] = useState(() => localStorage.getItem('sahm_trial_banned') === 'true');

  // Trial duration countdown (3 hours)
  const [trialTimeLeft, setTrialTimeLeft] = useState<number | null>(null);

  // Free trial registrations lists and logs in admin screen
  const [trials, setTrials] = useState<{ id: string; fingerprint: string; deviceId: string; ip: string; createdAt: string; expiresAt: string; accessCode: string; status: 'active' | 'expired' }[]>([]);
  const [trialLogs, setTrialLogs] = useState<{ timestamp: string; event: string; ip: string; fingerprint: string; deviceId: string; details: string }[]>([]);
  const [activeAccessCode, setActiveAccessCode] = useState<string>(() => localStorage.getItem('sahm_access_code') || '');

  // Advanced client-side Device fingerprinting
  const getCanvasHash = (): string => {
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return 'no_ctx';
      ctx.textBaseline = "top";
      ctx.font = "14px 'Arial'";
      ctx.fillText("sahm_pro_secure_fp_v1", 2, 2);
      ctx.fillStyle = "#f60";
      ctx.fillRect(100, 5, 50, 10);
      const dataUrl = canvas.toDataURL();
      let hash = 0;
      for (let i = 0; i < dataUrl.length; i++) {
        hash = (hash << 5) - hash + dataUrl.charCodeAt(i);
        hash |= 0;
      }
      return Math.abs(hash).toString(16);
    } catch (e) {
      return 'err';
    }
  };

  const getEnhancedFingerprint = (): string => {
    const parts = [
      navigator.userAgent,
      screen.width + "x" + screen.height,
      screen.colorDepth,
      new Date().getTimezoneOffset(),
      navigator.language,
      getCanvasHash()
    ];
    const str = parts.join('|');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return 'fp_' + Math.abs(hash).toString(16);
  };

  const getOrCreateDeviceId = (): string => {
    let devId = localStorage.getItem('sahm_device_id');
    if (!devId) {
      const cookies = document.cookie.split(';');
      const sahmCook = cookies.find(c => c.trim().startsWith('sahm_device_id='));
      if (sahmCook) {
        devId = sahmCook.split('=')[1];
        localStorage.setItem('sahm_device_id', devId);
      } else {
        devId = 'dev_' + Math.random().toString(36).substring(2, 11) + '_' + Date.now().toString(36);
        localStorage.setItem('sahm_device_id', devId);
        document.cookie = "sahm_device_id=" + devId + "; max-age=" + (10 * 365 * 24 * 60 * 60) + "; path=/; SameSite=Lax";
      }
    } else {
      document.cookie = "sahm_device_id=" + devId + "; max-age=" + (10 * 365 * 24 * 60 * 60) + "; path=/; SameSite=Lax";
    }
    return devId;
  };

  // Sync trial on mount if logged in as trial
  useEffect(() => {
    if (isLoggedIn && userRole === 'trial' && activeAccessCode) {
      const checkInitialStatus = async () => {
        try {
          const fp = getEnhancedFingerprint();
          const devId = getOrCreateDeviceId();
          const response = await fetch(`/api/trial/status?code=${activeAccessCode}&deviceId=${devId}&fingerprint=${fp}`);
          if (response.ok) {
            const data = await response.json();
            if (data.status === 'banned' || data.status === 'expired' || data.status === 'invalid') {
              localStorage.setItem('sahm_trial_banned', 'true');
              setIsDeviceBanned(true);
              handleLogout();
            } else if (data.status === 'active' && data.timeLeftSec !== undefined) {
              setTrialTimeLeft(data.timeLeftSec);
            }
          }
        } catch (e) {
          console.error(e);
        }
      };
      checkInitialStatus();
    }
  }, [isLoggedIn, userRole, activeAccessCode]);

  // Synchronized countdown timer interval
  useEffect(() => {
    if (trialTimeLeft === null || !isLoggedIn) return;
    
    // Decrement local count every second
    const interval = setInterval(() => {
      setTrialTimeLeft(prev => {
        if (prev === null) return null;
        if (prev <= 1) {
          clearInterval(interval);
          localStorage.setItem('sahm_trial_banned', 'true');
          setIsDeviceBanned(true);
          handleLogout();
          alert("انتهت فترة الـ 3 ساعات التجريبية الخاصة بك بالكامل وحُظر هذا المتصفح.");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [trialTimeLeft, isLoggedIn]);

  // Periodic status ping (every 15s) to guarantee server synchronization and anti-bypass
  useEffect(() => {
    if (!isLoggedIn || userRole !== 'trial' || !activeAccessCode) return;

    const interval = setInterval(async () => {
      try {
        const fp = getEnhancedFingerprint();
        const devId = getOrCreateDeviceId();
        const response = await fetch(`/api/trial/status?code=${activeAccessCode}&deviceId=${devId}&fingerprint=${fp}`);
        if (response.ok) {
          const data = await response.json();
          if (data.status === 'banned' || data.status === 'expired' || data.status === 'invalid') {
            clearInterval(interval);
            localStorage.setItem('sahm_trial_banned', 'true');
            setIsDeviceBanned(true);
            handleLogout();
            alert("عذراً، تم إلغاء الجلسة التجريبية بسبب انتهائها على السيرفر أو حدوث انتهاك أمني.");
          } else if (data.status === 'active' && data.timeLeftSec !== undefined) {
            setTrialTimeLeft(data.timeLeftSec);
          }
        }
      } catch (err) {
        console.error("Failed to sync trial status", err);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [isLoggedIn, userRole, activeAccessCode]);

  // Image Analysis State
  const [activeTab, setActiveTab] = useState<'image-analysis' | 'sahm-gpt' | 'admin-codes'>('image-analysis');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageUrlInput, setImageUrlInput] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>('1س');
  const [imageDimensions, setImageDimensions] = useState<{ width: number, height: number } | null>(null);

  // Sahm GPT State
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'model', text: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Local storage backup database helpers for static hosting (Netlify/Vercel)
  const getLocalBackupCodes = (): { id: string; code: string; createdAt: string; status: 'active' | 'disabled' }[] => {
    try {
      const stored = localStorage.getItem('sahm_local_codes');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  };

  const saveLocalBackupCodes = (codes: any[]) => {
    try {
      localStorage.setItem('sahm_local_codes', JSON.stringify(codes));
    } catch (e) {
      console.error(e);
    }
  };

  const generateClientSideCode = (length = 26): string => {
    const lettersUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lettersLower = "abcdefghijklmnopqrstuvwxyz";
    const numbers = "0123456789";
    const specials = "!@#$%^&*()_+{}[]";
    const allChars = lettersUpper + lettersLower + numbers + specials;
    
    let result = "";
    const getRandomByte = (): number => {
      if (typeof window !== "undefined" && window.crypto && window.crypto.getRandomValues) {
        const arr = new Uint8Array(1);
        window.crypto.getRandomValues(arr);
        return arr[0];
      }
      return Math.floor(Math.random() * 256);
    };

    result += lettersUpper[getRandomByte() % lettersUpper.length];
    result += lettersLower[getRandomByte() % lettersLower.length];
    result += numbers[getRandomByte() % numbers.length];
    result += specials[getRandomByte() % specials.length];

    while (result.length < length) {
      const idx = getRandomByte() % allChars.length;
      result += allChars[idx];
    }

    return result.split("").sort(() => getRandomByte() - 128).join("");
  };

  // Load access codes, active trials, and security logs for Admin
  const fetchAdminTrialsAndLogs = async () => {
    if (userRole !== 'admin') return;
    try {
      const responseTr = await fetch('/api/admin/trials');
      if (responseTr.ok) {
        const trData = await responseTr.json();
        setTrials(trData);
      }
      const responseLogs = await fetch('/api/admin/trial-logs');
      if (responseLogs.ok) {
        const logsData = await responseLogs.json();
        setTrialLogs(logsData);
      }
    } catch (err) {
      console.error("Failed to load trial info:", err);
    }
  };

  const fetchAdminCodes = async () => {
    if (userRole !== 'admin') return;
    try {
      setIsAdminLoading(true);
      const response = await fetch('/api/admin/codes');
      if (response.ok) {
        const data = await response.json();
        setAccessCodes(data);
      } else {
        setAccessCodes(getLocalBackupCodes());
      }

      const logsResp = await fetch('/api/admin/audit-logs');
      if (logsResp.ok) {
        const logsData = await logsResp.json();
        setAuditLogs(logsData);
      }

      await fetchAdminTrialsAndLogs();
    } catch (err) {
      console.error("Failed to load codes:", err);
      setAccessCodes(getLocalBackupCodes());
    } finally {
      setIsAdminLoading(false);
    }
  };

  useEffect(() => {
    if (isLoggedIn && userRole === 'admin') {
      fetchAdminCodes();
    }
  }, [isLoggedIn, userRole]);

  // Action handlers
  const handleGenerateCode = async () => {
    try {
      setIsAdminLoading(true);
      const response = await fetch('/api/admin/codes/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          expiresAt: generationExpiresAt || null,
          maxUses: generationMaxUses || null
        })
      });
      if (response.ok) {
        const newCode = await response.json();
        setAccessCodes(prev => [newCode, ...prev]);
        setGenerationExpiresAt('');
        setGenerationMaxUses('');
        
        // Refresh audit logs
        const logsResp = await fetch('/api/admin/audit-logs');
        if (logsResp.ok) {
          setAuditLogs(await logsResp.json());
        }
      } else {
        // Fallback for Netlify/400/404 responses
        const localList = getLocalBackupCodes();
        let code = "";
        for (let i = 0; i < 100; i++) {
          code = generateClientSideCode(26);
          if (!localList.some(c => c.code === code)) {
            break;
          }
        }
        const clientCode = {
          id: 'local_' + Math.random().toString(36).substring(2, 11),
          code,
          createdAt: new Date().toISOString(),
          status: 'active' as const,
          expiresAt: generationExpiresAt || null,
          maxUses: generationMaxUses ? parseInt(generationMaxUses, 10) : null,
          usedCount: 0,
          redemptions: []
        };
        const updated = [clientCode, ...localList];
        saveLocalBackupCodes(updated);
        setAccessCodes(updated);
        setGenerationExpiresAt('');
        setGenerationMaxUses('');
      }
    } catch (err: any) {
      console.error(err);
      // Fallback on total connection failure
      const localList = getLocalBackupCodes();
      let code = "";
      for (let i = 0; i < 100; i++) {
        code = generateClientSideCode(26);
        if (!localList.some(c => c.code === code)) {
          break;
        }
      }
      const clientCode = {
        id: 'local_' + Math.random().toString(36).substring(2, 11),
        code,
        createdAt: new Date().toISOString(),
        status: 'active' as const
      };
      const updated = [clientCode, ...localList];
      saveLocalBackupCodes(updated);
      setAccessCodes(updated);
    } finally {
      setIsAdminLoading(false);
    }
  };

  const handleToggleCode = async (id: string) => {
    try {
      const response = await fetch('/api/admin/codes/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (response.ok) {
        const data = await response.json();
        setAccessCodes(prev => prev.map(c => c.id === id ? data.item : c));
      } else {
        const localList = getLocalBackupCodes();
        const updated = localList.map(c => {
          if (c.id === id) {
            return { ...c, status: (c.status === 'active' ? 'disabled' : 'active') as any };
          }
          return c;
        });
        saveLocalBackupCodes(updated);
        setAccessCodes(updated);
      }
    } catch (err) {
      console.error(err);
      const localList = getLocalBackupCodes();
      const updated = localList.map(c => {
        if (c.id === id) {
          return { ...c, status: (c.status === 'active' ? 'disabled' : 'active') as any };
        }
        return c;
      });
      saveLocalBackupCodes(updated);
      setAccessCodes(updated);
    }
  };

  const handleDeleteCode = async (id: string) => {
    if (!window.confirm("هل أنت متأكد من رغبتك في حذف كود الوصول هذا نهائياً من قاعدة البيانات؟")) return;
    try {
      const response = await fetch('/api/admin/codes/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      });
      if (response.ok) {
        setAccessCodes(prev => prev.filter(c => c.id !== id));
      } else {
        const localList = getLocalBackupCodes();
        const updated = localList.filter(c => c.id !== id);
        saveLocalBackupCodes(updated);
        setAccessCodes(updated);
      }
    } catch (err) {
      console.error(err);
      const localList = getLocalBackupCodes();
      const updated = localList.filter(c => c.id !== id);
      saveLocalBackupCodes(updated);
      setAccessCodes(updated);
    }
  };

  const handleClearBans = async () => {
    if (!window.confirm("هل تريد تصفير قائمة المحظورين بالكامل وإعادة السماح بالأجهزة للتجربة؟")) return;
    try {
      const response = await fetch('/api/admin/bans/clear', {
        method: 'POST'
      });
      if (response.ok) {
        localStorage.removeItem('sahm_trial_banned');
        localStorage.removeItem('sahm_trial_end_time');
        setIsDeviceBanned(false);
        setTrials([]);
        setTrialLogs([]);
        await fetchAdminCodes();
        alert("تم تصفير وسحب قائمة الحظر بنجاح! جميع الأجهزة مقبولة الآن للولوج.");
      } else {
        localStorage.removeItem('sahm_trial_banned');
        localStorage.removeItem('sahm_trial_end_time');
        setIsDeviceBanned(false);
        alert("تم إعادة تهيئة الحظر في متصفحك محلياً.");
      }
    } catch (err) {
      console.error(err);
      localStorage.removeItem('sahm_trial_banned');
      localStorage.removeItem('sahm_trial_end_time');
      setIsDeviceBanned(false);
      alert("تم إعادة تهيئة الحظر في متصفحك محلياً.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('sahm_logged_in');
    localStorage.removeItem('sahm_user_role');
    localStorage.removeItem('sahm_trial_end_time');
    localStorage.removeItem('sahm_access_code');
    setIsLoggedIn(false);
    setUserRole(null);
    setTrialTimeLeft(null);
    setActiveAccessCode('');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const isBanned = localStorage.getItem('sahm_trial_banned') === 'true';
    if (isBanned && passwordInput !== 'ONER+AA_IS') {
      setIsDeviceBanned(true);
      setLoginError('عذراً، هذا الجهاز وعنوان الإنترنت الخاص بك خاضعان لقرار حظر أمني نشط بسبب انتهاء فترة تجربة ومراجعة الموقع.');
      return;
    }

    try {
      const devId = getOrCreateDeviceId();
      const fp = getEnhancedFingerprint();

      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          password: passwordInput,
          localBan: isBanned ? 'true' : 'false',
          userAgent: navigator.userAgent,
          deviceId: devId,
          fingerprint: fp
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setIsLoggedIn(true);
          setUserRole(data.role);
          localStorage.setItem('sahm_logged_in', 'true');
          localStorage.setItem('sahm_user_role', data.role);
          localStorage.setItem('sahm_access_code', passwordInput);
          setActiveAccessCode(passwordInput);

          if (data.role === 'trial' && data.timeLeftSec !== undefined) {
            setTrialTimeLeft(data.timeLeftSec);
          } else {
            setTrialTimeLeft(null);
          }
          setLoginError(null);
          setPasswordInput('');
        }
      } else {
        if (response.status === 400 || response.status === 404 || response.status === 405) {
          throw new Error('Fallback to local simulation');
        }
        
        const errData = await response.json().catch(() => ({}));
        if (errData.triggerBan) {
          localStorage.setItem('sahm_trial_banned', 'true');
          setIsDeviceBanned(true);
        }
        setLoginError(errData.error || 'الرمز السري غير صحيح، حاول مرة أخرى.');
        setPasswordInput('');
      }
    } catch (err) {
      console.error(err);
      if (passwordInput === 'ONER+AA_IS') {
        setIsLoggedIn(true);
        setUserRole('admin');
        localStorage.setItem('sahm_logged_in', 'true');
        localStorage.setItem('sahm_user_role', 'admin');
        setLoginError(null);
        setPasswordInput('');
        return;
      }

      // Simulation fallback for offline or isolated networks
      const localList = getLocalBackupCodes();
      const matching = localList.find(c => c.code === passwordInput);
      if (matching) {
        if (matching.status === 'disabled') {
          setLoginError('عذراً، هذا الكود تم تعطيله وإيقافه مؤقتاً من قِبل مدير المنصة.');
          return;
        }
        setIsLoggedIn(true);
        setUserRole('regular');
        localStorage.setItem('sahm_logged_in', 'true');
        localStorage.setItem('sahm_user_role', 'regular');
        localStorage.setItem('sahm_access_code', passwordInput);
        setActiveAccessCode(passwordInput);
        setLoginError(null);
        setPasswordInput('');
      } else {
        setLoginError('كود التفعيل غير صالح. تأكد من إدخال رمز صحيح.');
      }
      setPasswordInput('');
    }
  };

  const [isClaimingTrial, setIsClaimingTrial] = useState(false);

  const handleClaimTrial = async () => {
    setIsClaimingTrial(true);
    setLoginError(null);
    try {
      const fp = getEnhancedFingerprint();
      const devId = getOrCreateDeviceId();

      const response = await fetch('/api/trial/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fingerprint: fp, deviceId: devId })
      });

      const data = await response.json();
      if (!response.ok) {
        setLoginError(data.error || "فشل في تفعيل النسخة التجريبية.");
        if (response.status === 444 || response.status === 400 || response.status === 403) {
          localStorage.setItem('sahm_trial_banned', 'true');
          setIsDeviceBanned(true);
        }
        return;
      }

      if (data.success && data.code) {
        setIsLoggedIn(true);
        setUserRole('trial');
        setActiveAccessCode(data.code);
        setTrialTimeLeft(data.timeLeftSec || 10800);
        localStorage.setItem('sahm_logged_in', 'true');
        localStorage.setItem('sahm_user_role', 'trial');
        localStorage.setItem('sahm_access_code', data.code);
        alert(`تم تفعيل تجربتك المجانية لمدة 3 ساعات بنجاح! كود التفعيل الخاص بك هو:\n\n${data.code}\n\nيرجى حفظ الكود.`);
      }
    } catch (err: any) {
      console.error(err);
      setLoginError("حدث خطأ أثناء الاتصال بالخادم. يرجى المحاولة لاحقاً.");
    } finally {
      setIsClaimingTrial(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          setImageDimensions({ width: img.width, height: img.height });
        };
        img.src = reader.result as string;
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setAnalysisResult(null);
      setAnalysisError(null);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage && !imageUrlInput) {
      // If nothing is selected, use a default sample image for demo
      setImageUrlInput("https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg");
      setImagePreview("https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg");
    }

    setIsAnalyzing(true);
    setAnalysisError(null);
    setAnalysisResult(null);

    const prompt = `أنت محلل أسواق مالية محترف (Institutional Trader AI) بقدرات رؤية حاسوبية فائقة.
عند استلام صورة شارت (Candlestick Chart يحتوي على سعر + زمن)، قم بتحليلها بشكل مؤسسي شامل باستخدام المدارس التالية:
Ⅰ. الاتجاه والسلوك السعري: Elliott Wave, Wyckoff, Smart Money Concepts (BOS, CHoCH, OB, FVG), ICT, Supply & Demand.
Ⅱ. التحليل الزمني والرياضي: Fibonacci, Time Cycles.
Ⅲ. الحجم والتدفقات: Volume Analysis, Volume Profile.

⚠️ ملاحظة هامة حول جودة الصورة:
- يرجى التعامل مع جميع جودات الصور (سواء كانت عالية الدقة أو منخفضة أو حتى مشوشة).
- استخدم قدراتك في استنتاج البيانات المفقودة من خلال سياق الشارت والشموع المحيطة.
- قم بتحليل جميع القياسات والأبعاد والنسب المئوية الموجودة في الصورة بدقة متناهية، مع التركيز على المسافات بين القمم والقيعان وحساب الأهداف بناءً على هذه القياسات الرياضية الظاهرة في الشارت.

مع العلم أن الفريم الزمني المستخدم هو: ${selectedTimeframe}

📊 المطلوب تقرير مفصل يشمل:
1. الاتجاه العام للسوق.
2. تحديد مناطق السيولة القريبة.
3. توصية واضحة: (شراء / بيع / حياد).
4. تفاصيل الصفقة بالأرقام الدقيقة (بناءً على مستويات السعر في الشارت):
   - نقطة الدخول (Entry Price): [رقم محدد]
   - الهدف الأول (TP1): [رقم محدد]
   - الهدف الثاني (TP2): [رقم محدد]
   - وقف الخسارة (Stop Loss): [رقم محدد]
5. نسبة النجاح المتوقعة بناءً على الأبعاد والقياسات المرصودة.

⚠️ ملاحظة: يجب أن تكون جميع الأسعار المذكورة أرقاماً واقعية مستخرجة من مستويات السعر الظاهرة في الصورة المرفوعة.

يرجى كتابة التحليل باللغة العربية بأسلوب احترافي.`;

    try {
      let response;
      const devId = getOrCreateDeviceId();
      const fp = getEnhancedFingerprint();
      
      if (selectedImage) {
        const formData = new FormData();
        formData.append("image", selectedImage);
        formData.append("prompt", prompt); // Send prompt to backend too
        
        response = await fetch('/api/analyze', {
          method: 'POST',
          headers: {
            'X-Access-Code': activeAccessCode,
            'X-Device-Id': devId,
            'X-Fingerprint': fp
          },
          body: formData
        });
      } else {
        response = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'X-Access-Code': activeAccessCode,
            'X-Device-Id': devId,
            'X-Fingerprint': fp
          },
          body: JSON.stringify({ 
            image_url: imageUrlInput || "https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg",
            prompt: prompt
          }),
        });
      }

      if (response.status === 401 || response.status === 403) {
        const errData = await response.json().catch(() => ({}));
        setAnalysisError(errData.error || "عذراء، تم إنهاء هذه الجلسة لمخالفة أمنية أو لانتهاء المدة الزمنية.");
        localStorage.setItem('sahm_trial_banned', 'true');
        setIsDeviceBanned(true);
        handleLogout();
        setIsAnalyzing(false);
        return;
      }

      if (response.ok) {
        const data = await response.json();
        const resultText = data.analysis || 
                           data.choices?.[0]?.message?.content || 
                           data.candidates?.[0]?.content?.parts?.[0]?.text ||
                           (typeof data === 'string' ? data : null);
        
        if (resultText) {
          setAnalysisResult(resultText);
          setIsAnalyzing(false);
          return;
        }
      }

      // Fallback to Gemini directly if backend fails or returns no text
      console.log("Backend analysis failed or empty, falling back to Gemini...");
      const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || 'AIzaSyBgN87E6HQz0p-nv8FXfmafDT9fnpubA3Q' });

      let geminiInput: any[] = [prompt];
      
      if (selectedImage) {
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        });
        reader.readAsDataURL(selectedImage);
        const base64Data = await base64Promise;
        geminiInput.push({
          inlineData: {
            data: base64Data,
            mimeType: selectedImage.type
          }
        });
      } else {
        // For URL, we'd ideally fetch it, but Gemini can't take URLs directly in inlineData
        // So we'll just send the prompt and mention the URL if we can't fetch it
        geminiInput[0] = `${prompt}\n\nملاحظة: يرجى تحليل الصورة الموجودة في هذا الرابط: ${imageUrlInput || "https://upload.wikimedia.org/wikipedia/commons/3/3f/Fronalpstock_big.jpg"}`;
      }

      const result = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: geminiInput.map(part => typeof part === 'string' ? { text: part } : part)
          }
        ]
      });
      setAnalysisResult(result.text);

    } catch (error: any) {
      console.error("Analysis error:", error);
      setAnalysisError("عذراً، واجهنا مشكلة في التحليل. تأكد من جودة الصورة أو الرابط وحاول مجدداً.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const sendChatMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const isBanned = localStorage.getItem('sahm_trial_banned') === 'true';
    if (isBanned) {
      setIsDeviceBanned(true);
      setLoginError('عذراً، هذا الجهاز وعنوان الإنترنت الخاص بك خاضعان لقرار حظر أمني نشط بسبب انتهاء فترة تجربة ومراجعة الموقع.');
      handleLogout();
      return;
    }

    const userMessage = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsChatLoading(true);

    try {
      // Try Groq first
      try {
        const groq = new Groq({ 
          apiKey: process.env.GROQ_API_KEY || 'mega_99a4af63325873205ce04c8f9d2dbe435e0a74ab049c1f3e7521db0940c69cad',
          dangerouslyAllowBrowser: true 
        });
        
        const systemInstruction = `أنت sahm gpt، خبير أسواق مالية عالمي (Institutional Trading Expert AI) بخبرة عميقة في جميع مجالات التداول.
🎯 مهمتك: الإجابة على جميع أسئلة المستخدم المتعلقة بـ: التداول، التحليل الفني، التحليل الأساسي، إدارة المخاطر، وسيكولوجية التداول.
📊 أسلوبك: احترافي، واضح، مباشر، مع شرح الأسباب (WHY + HOW).
📈 عند طلب تحليل: حدد الاتجاه، السلوك السعري، مناطق العرض والطلب، والسيولة. يجب إعطاء أرقام دقيقة لـ (دخول، SL، TP) بناءً على مستويات الشارت.
⚠️ إدارة المخاطر: لا توصي بدون وقف خسارة، اقترح مخاطرة 1% - 2%.
🧠 كن واقعياً ولا تبالغ في التوقعات.`;

        const response = await groq.chat.completions.create({
          messages: [
            { role: 'system', content: systemInstruction },
            ...chatMessages.map(msg => ({
              role: msg.role === 'model' ? 'assistant' as const : 'user' as const,
              content: msg.text
            })),
            { role: 'user', content: userMessage }
          ],
          model: "llama-3.3-70b-versatile",
        });
        
        const resultText = response.choices[0]?.message?.content;
        if (resultText) {
          setChatMessages(prev => [...prev, { role: 'model', text: resultText }]);
          return;
        }
      } catch (groqError) {
        console.warn("Groq chat failed, falling back to Gemini:", groqError);
      }

      // Fallback to Gemini
      const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || 'AIzaSyBgN87E6HQz0p-nv8FXfmafDT9fnpubA3Q' });
      
      const systemInstruction = `أنت sahm gpt، خبير أسواق مالية عالمي (Institutional Trading Expert AI) بخبرة عميقة في جميع مجالات التداول.
🎯 مهمتك: الإجابة على جميع أسئلة المستخدم المتعلقة بـ: التداول، التحليل الفني، التحليل الأساسي، إدارة المخاطر، وسيكولوجية التداول.
📊 أسلوبك: احترافي، واضح، مباشر، مع شرح الأسباب (WHY + HOW).
📈 عند طلب تحليل: حدد الاتجاه، السلوك السعري، مناطق العرض والطلب، والسيولة. يجب إعطاء أرقام دقيقة لـ (دخول، SL، TP) بناءً على مستويات الشارت.
⚠️ إدارة المخاطر: لا توصي بدون وقف خسارة، اقترح مخاطرة 1% - 2%.
🧠 كن واقعياً ولا تبالغ في التوقعات.`;

      const response = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          ...chatMessages.map(msg => ({
            role: msg.role === 'model' ? 'model' : 'user',
            parts: [{ text: msg.text }]
          })),
          { role: 'user', parts: [{ text: userMessage }] }
        ],
        config: {
          systemInstruction: systemInstruction,
        }
      });
      
      const resultText = response.text;
      if (resultText) {
        setChatMessages(prev => [...prev, { role: 'model', text: resultText }]);
      }
    } catch (error) {
      console.error("Chat error:", error);
      setChatMessages(prev => [...prev, { role: 'model', text: "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const TradingSessions = () => {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
      const timer = setInterval(() => setCurrentTime(new Date()), 1000);
      return () => clearInterval(timer);
    }, []);

    const sessions = [
      { 
        name: 'طوكيو (Tokyo)', 
        start: 3, 
        end: 12, 
        color: 'blue', 
        icon: '🔵', 
        desc: 'حركة USDJPY نشيطة' 
      },
      { 
        name: 'لندن (London)', 
        start: 10, 
        end: 19, 
        color: 'yellow', 
        icon: '🟡', 
        desc: 'أقوى سيولة، بداية الحركة الحقيقية' 
      },
      { 
        name: 'نيويورك (New York)', 
        start: 16, 
        end: 25, 
        color: 'red', 
        icon: '🔴', 
        desc: 'حركة قوية وتداخل مع لندن' 
      },
    ];

    // Assuming KSA time (UTC+3)
    const ksaHour = (currentTime.getUTCHours() + 3) % 24;
    const ksaHourAdjusted = ksaHour < 3 ? ksaHour + 24 : ksaHour;

    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
        {sessions.map((s) => {
          const isOpen = ksaHourAdjusted >= s.start && ksaHourAdjusted < s.end;
          const colorMap: Record<string, string> = {
            blue: 'blue',
            yellow: 'yellow',
            red: 'red'
          };
          const c = colorMap[s.color];
          
          return (
            <motion.div 
              key={s.name}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`p-6 rounded-[2rem] border-2 transition-all duration-500 ${isOpen ? `border-${c}-500 bg-${c}-50 shadow-xl shadow-${c}-100` : 'border-emerald-100 bg-white opacity-50'}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{s.icon}</span>
                  <h4 className="font-black text-emerald-900 text-lg">{s.name}</h4>
                </div>
                {isOpen && (
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">مفتوح الآن</span>
                    <span className={`flex h-3 w-3 rounded-full bg-${c}-500 animate-pulse`}></span>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm font-bold text-emerald-800">
                  <span>تفتح: {s.start}:00 ص</span>
                  <span>تغلق: {s.end > 24 ? s.end - 24 : s.end}:00 {s.end > 12 && s.end <= 24 ? 'م' : 'ص'}</span>
                </div>
                <div className="h-1.5 w-full bg-emerald-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: isOpen ? '100%' : '0%' }}
                    className={`h-full bg-${c}-500`}
                  />
                </div>
                <p className="text-xs text-emerald-500 font-medium leading-relaxed">{s.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    );
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-emerald-900 bg-gradient-to-br from-emerald-700 via-emerald-850 to-emerald-950 flex items-center justify-center p-6 text-white" dir="rtl">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/95 backdrop-blur-md w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl space-y-8 text-center border border-emerald-50"
        >
          {isDeviceBanned ? (
            <div className="space-y-6">
              <div className="bg-rose-100 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto text-rose-600 shadow-xl shadow-rose-200">
                <Ban className="w-10 h-10" />
              </div>
              <div className="space-y-3">
                <h1 className="text-3xl font-black text-rose-950">قفل الحظر الأمني</h1>
                <p className="text-rose-600 font-bold text-sm leading-relaxed">
                  تم حظر هذا الجهاز تماماً عن خدمات شبكة المنصة.
                </p>
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-xs text-rose-800 font-medium text-right leading-relaxed space-y-2">
                  <p className="font-extrabold text-rose-900 border-b border-rose-150 pb-1.5">مخرجات نظام تتبع الثقة والوصول:</p>
                  <ul className="list-disc list-inside space-y-1.5">
                    <li>انتهاء فترة الصلاحية المجانية المقدّرة بـ 3 ساعات.</li>
                    <li>استخدام كلمة مرور موقوفة بشكل دائم من قِبل المشرف.</li>
                  </ul>
                </div>
              </div>
              
              <div className="pt-4 border-t border-rose-100 space-y-4">
                <p className="text-emerald-600 text-xs font-semibold">هل أنت المشرف على سهم برو؟ أدخل رمز الإدارة لإلغاء القفل:</p>
                <form onSubmit={handleLogin} className="space-y-3">
                  <input 
                    type="password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="كود الإدارة المميز"
                    className="w-full bg-emerald-50 border-2 border-emerald-100 px-4 py-3 rounded-xl text-center font-bold text-emerald-900 text-sm focus:outline-none focus:border-emerald-600 transition-all placeholder:text-emerald-300"
                  />
                  <button 
                    type="submit"
                    className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold text-sm shadow-md hover:bg-emerald-700 transition"
                  >
                    تسجيل دخول مدير المنصة
                  </button>
                </form>
                {loginError && (
                  <p className="text-rose-600 font-bold text-xs">{loginError}</p>
                )}
              </div>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="bg-emerald-600 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-emerald-200">
                  <ShieldCheck className="w-10 h-10 text-white" />
                </div>
                <h1 className="text-3xl font-black text-emerald-900">سهم برو</h1>
                <p className="text-emerald-500 font-medium">يرجى إدخال رمز الدخول للمتابعة</p>
              </div>

              <form onSubmit={handleLogin} className="space-y-6">
                <div className="space-y-2">
                  <input 
                    type="password"
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="أدخل الرمز السري أو كود الوصول"
                    className={`w-full bg-emerald-50 border-2 ${loginError ? 'border-rose-300' : 'border-emerald-100'} px-6 py-4 rounded-2xl text-center text-xl font-bold focus:outline-none focus:border-emerald-600 transition-all text-emerald-950 placeholder:text-emerald-300`}
                    autoFocus
                  />
                  {loginError && (
                    <motion.p 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-rose-600 text-xs font-bold leading-relaxed bg-rose-50 border border-rose-100 p-2.5 rounded-xl mt-2"
                    >
                      {loginError}
                    </motion.p>
                  )}
                </div>
                <button 
                  type="submit"
                  className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
                >
                  دخول المنصة
                </button>
              </form>

              <div className="flex items-center gap-3 my-4 animate-pulse">
                <div className="h-[1px] bg-emerald-100 flex-1"></div>
                <span className="text-[10px] text-emerald-500 font-extrabold uppercase tracking-wider">أو ابدأ فوراً</span>
                <div className="h-[1px] bg-emerald-100 flex-1"></div>
              </div>

              <button 
                type="button"
                onClick={handleClaimTrial}
                disabled={isClaimingTrial}
                className="w-full bg-emerald-50/50 hover:bg-emerald-50 text-emerald-700 hover:text-emerald-800 py-4 border-2 border-emerald-100/80 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-2.5 active:scale-[0.98]"
              >
                {isClaimingTrial ? (
                  <RefreshCw className="w-4.5 h-4.5 animate-spin text-emerald-600" />
                ) : (
                  <Sparkles className="w-4.5 h-4.5 text-emerald-600 animate-pulse" />
                )}
                تفعيل تجربة مجانية لمدة 3 ساعات الآن
              </button>

              <div className="pt-4 border-t border-emerald-50 flex flex-col gap-1.5">
                <p className="text-emerald-400 text-xs font-medium">منصة حصرية للأعضاء والمشتركين فقط</p>
              </div>
            </>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-emerald-50 font-sans text-emerald-900 selection:bg-emerald-200" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-emerald-100 px-6 py-4 sticky top-0 z-50 backdrop-blur-md bg-white/80">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center justify-between w-full sm:w-auto">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-200">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-black text-emerald-800 tracking-tight">سهم برو</h1>
              </div>
            </div>
            
            {/* Mobile Logout (visible on mobile only) */}
            <button 
              onClick={handleLogout}
              className="sm:hidden bg-rose-50 text-rose-600 border border-rose-100 p-2.5 rounded-xl"
              title="خروج"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto">
            <div className="flex bg-emerald-50 p-1 rounded-2xl border border-emerald-100 overflow-x-auto max-w-full">
              <button 
                onClick={() => setActiveTab('image-analysis')}
                className={`px-4 sm:px-6 py-2 rounded-xl font-bold text-sm transition-all whitespace-nowrap ${activeTab === 'image-analysis' ? 'bg-emerald-600 text-white shadow-lg' : 'text-emerald-600 hover:bg-emerald-100'}`}
              >
                تحليل من صورة
              </button>
              <button 
                onClick={() => setActiveTab('sahm-gpt')}
                className={`px-4 sm:px-6 py-2 rounded-xl font-bold text-sm transition-all whitespace-nowrap ${activeTab === 'sahm-gpt' ? 'bg-emerald-600 text-white shadow-lg' : 'text-emerald-600 hover:bg-emerald-100'}`}
              >
                Sahm GPT
              </button>
              {userRole === 'admin' && (
                <button 
                  onClick={() => setActiveTab('admin-codes')}
                  className={`px-4 sm:px-6 py-2 rounded-xl font-bold text-sm transition-all whitespace-nowrap ${activeTab === 'admin-codes' ? 'bg-emerald-600 text-white shadow-lg' : 'text-emerald-600 hover:bg-emerald-100'}`}
                >
                  إدارة الأكواد
                </button>
              )}
            </div>

            <div className="hidden sm:flex items-center gap-3">
              {userRole === 'trial' && trialTimeLeft !== null && (
                <div className="flex items-center gap-2 text-amber-700 font-bold bg-amber-50 px-4 py-2 rounded-full border border-amber-100 shadow-sm animate-pulse">
                  <Clock className="w-4 h-4 text-amber-600 animate-spin" style={{ animationDuration: '6s' }} />
                  <span className="text-xs whitespace-nowrap">
                    التجربة: {Math.floor(trialTimeLeft / 3600)}س : {Math.floor((trialTimeLeft % 3600) / 60)}د : {trialTimeLeft % 60}ث
                  </span>
                </div>
              )}
              <div className="flex items-center gap-2 text-emerald-600 font-bold bg-emerald-50 px-4 py-2 rounded-full border border-emerald-100">
                <ShieldCheck className="w-5 h-5" />
                <span className="text-xs whitespace-nowrap">توصيات ICT الذكية</span>
              </div>
              <button 
                onClick={handleLogout}
                className="bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 px-4 py-2 rounded-full font-bold text-sm transition-all flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>خروج</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12 space-y-12">
        <TradingSessions />
        {userRole === 'trial' && trialTimeLeft !== null && (
          <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-100 p-5 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl shadow-amber-100/30 text-right">
            <div className="flex items-center gap-3">
              <div className="bg-amber-100 p-2.5 rounded-2xl flex items-center justify-center shadow-inner">
                <Sparkles className="w-5 h-5 text-amber-700 animate-pulse" />
              </div>
              <div>
                <h4 className="font-extrabold text-amber-950 text-sm">أنت تستخدم ترخيص سهم برو التجريبي الآمن</h4>
                <p className="text-xs text-amber-600/95 mt-1 font-semibold">صلاحية تفعيل هذا الجهاز تنتهي بنهاية الـ 3 ساعات لضمان عدالة وموثوقية مراجعة التوصيات.</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 bg-white px-5 py-2.5 border border-amber-150 rounded-2xl shadow-inner font-mono text-amber-800 text-sm font-black whitespace-nowrap">
              <span>{Math.floor(trialTimeLeft / 3600)} ساعة</span>
              <span>:</span>
              <span>{Math.floor((trialTimeLeft % 3600) / 60)} دقيقة</span>
              <span>:</span>
              <span>{trialTimeLeft % 60} ثانية</span>
            </div>
          </div>
        )}
        {activeTab === 'image-analysis' ? (
          <div className="space-y-12">
            <section className="text-center space-y-6">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-block bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider mb-4"
              >
                تحليل مؤسسي شامل من الصورة
              </motion.div>
              <h2 className="text-4xl md:text-5xl font-black text-emerald-950 leading-tight">
                ارفع <span className="text-emerald-600">الشارت</span> <br />
                للحصول على تحليل احترافي
              </h2>
              <p className="text-emerald-600/80 text-lg max-w-xl mx-auto">
                قم برفع صورة واضحة للشارت (شموع + وقت + سعر) وسيقوم المحلل الآلي بتحليلها بناءً على أرقى المدارس الفنية.
              </p>
            </section>

            <section className="max-w-2xl mx-auto">
              <div className="bg-white rounded-[2.5rem] p-8 shadow-2xl shadow-emerald-200/50 border border-emerald-50 space-y-8">
                {/* Upload Area */}
                <div className="space-y-4">
                  <div className="relative group">
                    <input 
                      type="file" 
                      accept="image/*"
                      onChange={handleImageChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                    />
                    <div className={`
                      border-4 border-dashed rounded-3xl p-12 text-center transition-all duration-300
                      ${imagePreview ? 'border-emerald-500 bg-emerald-50' : 'border-emerald-100 bg-emerald-50/30 group-hover:border-emerald-300 group-hover:bg-emerald-50'}
                    `}>
                      {imagePreview ? (
                        <div className="relative">
                          <img src={imagePreview} alt="Preview" className="max-h-64 mx-auto rounded-2xl shadow-lg mb-4" />
                          <div className="flex flex-col items-center gap-2">
                            <div className="flex items-center justify-center gap-2 text-emerald-600 font-bold">
                              <CheckCircle2 className="w-5 h-5" />
                              <span>تم اختيار الصورة</span>
                            </div>
                            {imageDimensions && (
                              <p className="text-[10px] text-emerald-400 font-mono">
                                الأبعاد: {imageDimensions.width} × {imageDimensions.height} بكسل
                              </p>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-emerald-600">
                            <Upload className="w-8 h-8" />
                          </div>
                          <div>
                            <p className="text-lg font-black text-emerald-900">اضغط هنا لرفع الصورة</p>
                            <p className="text-emerald-400 text-sm">أو اسحب الصورة وأفلتها هنا</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="relative">
                    <div className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-emerald-600">
                      <Zap className="w-5 h-5" />
                    </div>
                    <input 
                      type="text" 
                      placeholder="أو ضع رابط الصورة هنا مباشرة..."
                      value={imageUrlInput}
                      onChange={(e) => {
                        setImageUrlInput(e.target.value);
                        if (e.target.value) {
                          setImagePreview(e.target.value);
                          setSelectedImage(null);
                        }
                      }}
                      className="w-full bg-emerald-50 border-2 border-emerald-100 rounded-2xl py-4 pr-12 pl-4 text-emerald-900 font-bold placeholder:text-emerald-300 focus:outline-none focus:border-emerald-500 transition-all"
                    />
                  </div>
                </div>

                {/* Timeframe Selection */}
                <div className="space-y-3">
                  <p className="text-emerald-900 font-black text-sm">اختر الفريم الزمني للشارت:</p>
                  <div className="grid grid-cols-4 md:grid-cols-7 gap-2">
                    {['1د', '5د', '15د', '30د', '1س', '4س', 'ي1'].map((tf) => (
                      <button
                        key={tf}
                        onClick={() => setSelectedTimeframe(tf)}
                        className={`
                          py-2 rounded-xl font-bold text-sm transition-all border-2
                          ${selectedTimeframe === tf 
                            ? 'bg-emerald-600 border-emerald-600 text-white shadow-md' 
                            : 'bg-white border-emerald-100 text-emerald-600 hover:border-emerald-300'}
                        `}
                      >
                        {tf}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <button
                  onClick={analyzeImage}
                  disabled={!selectedImage || isAnalyzing}
                  className={`
                    w-full py-5 rounded-2xl font-black text-xl flex items-center justify-center gap-3 transition-all
                    ${!selectedImage || isAnalyzing 
                      ? 'bg-emerald-100 text-emerald-300 cursor-not-allowed' 
                      : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xl shadow-emerald-200 active:scale-95'}
                  `}
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-6 h-6 animate-spin" />
                      <span>جاري التحليل المؤسسي...</span>
                    </>
                  ) : (
                    <>
                      <FileSearch className="w-6 h-6" />
                      <span>ابدأ التحليل الآن</span>
                    </>
                  )}
                </button>

                {analysisError && (
                  <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl flex items-center gap-3 text-rose-600">
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <p className="text-sm font-bold">{analysisError}</p>
                  </div>
                )}
              </div>
            </section>

            {/* Analysis Result */}
            <AnimatePresence>
              {analysisResult && (
                <motion.section
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-[2.5rem] shadow-2xl shadow-emerald-200/50 border border-emerald-50 overflow-hidden"
                >
                  <div className="bg-emerald-900 px-8 py-6 flex items-center justify-between text-white">
                    <div className="flex items-center gap-4">
                      <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md">
                        <BarChart3 className="w-8 h-8 text-emerald-400" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-black">نتائج التحليل المؤسسي</h3>
                        <p className="text-emerald-400 text-xs font-bold">Institutional Trader AI Analysis</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-8 md:p-12">
                    <div className="prose prose-emerald max-w-none prose-headings:font-black prose-headings:text-emerald-900 prose-p:text-emerald-800 prose-p:leading-relaxed prose-strong:text-emerald-950 prose-li:text-emerald-800" dir="rtl">
                      <ReactMarkdown>{analysisResult}</ReactMarkdown>
                    </div>
                  </div>
                </motion.section>
              )}
            </AnimatePresence>
          </div>
        ) : activeTab === 'sahm-gpt' ? (
          <div className="space-y-8">
            <section className="text-center space-y-4">
              <h2 className="text-4xl font-black text-emerald-950 block">Sahm GPT</h2>
              <p className="text-emerald-600 font-bold block">خبير الأسواق المالية العالمي بين يديك</p>
            </section>

            <div className="bg-white rounded-[2.5rem] shadow-2xl border border-emerald-50 flex flex-col h-[600px] overflow-hidden">
              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-emerald-50/30">
                {chatMessages.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                    <MessageSquare className="w-16 h-16 text-emerald-300" />
                    <p className="text-emerald-600 font-bold">ابدأ المحادثة مع Sahm GPT حول أي شيء يخص التداول</p>
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: msg.role === 'user' ? -20 : 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-[80%] flex gap-3 ${msg.role === 'user' ? 'flex-row' : 'flex-row-reverse'}`}>
                      <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md ${msg.role === 'user' ? 'bg-emerald-600 text-white' : 'bg-white text-emerald-600 border border-emerald-100'}`}>
                        {msg.role === 'user' ? <User className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
                      </div>
                      <div className={`p-4 rounded-3xl shadow-sm ${msg.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-white text-emerald-900 border border-emerald-100 rounded-tl-none'}`}>
                        <div className="prose prose-sm prose-emerald max-w-none prose-p:leading-relaxed">
                          <ReactMarkdown>{msg.text}</ReactMarkdown>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-end">
                    <div className="bg-white p-4 rounded-3xl border border-emerald-100 flex items-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
                      <span className="text-emerald-600 font-bold text-sm">جاري التفكير...</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={sendChatMessage} className="p-6 bg-white border-t border-emerald-100 flex gap-4">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="اسأل Sahm GPT عن أي صفقة أو استراتيجية..."
                  className="flex-1 bg-emerald-50 border-2 border-emerald-100 rounded-2xl px-6 py-4 focus:outline-none focus:border-emerald-600 transition-all font-bold"
                />
                <button
                  type="submit"
                  disabled={!chatInput.trim() || isChatLoading}
                  className={`bg-emerald-600 text-white p-4 rounded-2xl shadow-lg transition-all active:scale-95 ${(!chatInput.trim() || isChatLoading) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-emerald-700'}`}
                >
                  <Send className="w-6 h-6" />
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-fade-in" dir="rtl">
            <section className="text-center space-y-4">
              <div className="inline-block bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider mb-2">
                لوحة التحكم بالمشتركين والتراخيص الآمنة
              </div>
              <h2 className="text-4xl font-black text-emerald-950">إدارة أكواد الوصول الآمنة</h2>
              <p className="text-emerald-600 font-bold max-w-xl mx-auto">
                قم بإنشاء وسحب أكواد تفعيل جديدة للمشتركين بخصائص تشفير مخصصة. تم إيقاف كلمة المرور العادية لتعزيز خصوصية المنصة.
              </p>
            </section>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Action summary card */}
              <div className="md:col-span-1 bg-white p-6 rounded-[2rem] border border-emerald-100 shadow-xl shadow-emerald-200/40 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-emerald-900 text-lg mb-4 flex items-center gap-2">
                    <Key className="w-5 h-5 text-emerald-600" />
                    توليد الرموز الآمنة
                  </h3>
                  <p className="text-xs text-emerald-500 leading-relaxed font-semibold mb-4">
                    قم بتهيأ خصائص كود الدعوة والوصول المخصصة، ثم انقر لإنشائه بشكل مشفر وآمن.
                  </p>
                  
                  <div className="space-y-4 mb-6">
                    <div>
                      <label className="block text-[11px] font-black text-emerald-800 mb-1">الحد الأقصى للأجهزة (اختياري)</label>
                      <input 
                        type="number"
                        min="1"
                        placeholder="مثال: 3 (فارغ لعدد غير محدود)"
                        value={generationMaxUses}
                        onChange={(e) => setGenerationMaxUses(e.target.value)}
                        className="w-full text-xs font-bold bg-emerald-50/50 border border-emerald-100 rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all text-emerald-950"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-black text-emerald-800 mb-1">تاريخ انتهاء الصلاحية (اختياري)</label>
                      <input 
                        type="datetime-local"
                        value={generationExpiresAt}
                        onChange={(e) => setGenerationExpiresAt(e.target.value)}
                        className="w-full text-xs font-bold bg-emerald-50/50 border border-emerald-100 rounded-xl px-4 py-2.5 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all text-emerald-950"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <button 
                    onClick={handleGenerateCode}
                    disabled={isAdminLoading}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black py-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm"
                  >
                    {isAdminLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                    إنشاء كود جديد
                  </button>
                  <button 
                    onClick={handleClearBans}
                    className="w-full bg-rose-55 hover:bg-rose-100 text-rose-700 font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 text-xs border border-rose-100 bg-rose-50/50"
                  >
                    <Unlock className="w-4 h-4" />
                    تصفير الأجهزة المحظورة
                  </button>
                </div>
              </div>

              {/* Access code list table */}
              <div className="md:col-span-2 bg-white rounded-[2rem] border border-emerald-100 shadow-xl shadow-emerald-200/40 overflow-hidden">
                <div className="p-6 border-b border-emerald-50 bg-emerald-50/20 flex items-center justify-between">
                  <h3 className="font-bold text-emerald-950 text-lg">قائمة الأكواد الفعّالة ({accessCodes.length})</h3>
                  <button 
                    onClick={fetchAdminCodes}
                    className="text-emerald-600 hover:text-emerald-700 text-xs font-bold flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> تحديث القائمة
                  </button>
                </div>
                <div className="divide-y divide-emerald-50 max-h-[400px] overflow-y-auto">
                  {accessCodes.length === 0 ? (
                    <div className="p-12 text-center text-emerald-300 font-bold text-sm">
                      لا يوجد أي أكواد وصول صادرة حالياً. انقر على "إنشاء كود جديد" للبدء بالصرف.
                    </div>
                  ) : (
                    accessCodes.map((item) => (
                      <div key={item.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1.5 flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-emerald-950 text-xs font-bold bg-emerald-50 px-3 py-1.5 rounded-lg select-all truncate block border border-emerald-105">
                              {item.code}
                            </span>
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(item.code);
                                setCopiedCode(item.id);
                                setTimeout(() => setCopiedCode(null), 2000);
                              }}
                              className="text-emerald-500 hover:text-emerald-700 p-1.5 rounded hover:bg-emerald-50"
                              title="نسخ الكود"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            {copiedCode === item.id && (
                              <span className="text-[10px] text-emerald-600 font-black animate-pulse">تم النسخ!</span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[10px] text-emerald-400 font-bold mt-1">
                            <span>صادر: {new Date(item.createdAt).toLocaleString('ar-SA')}</span>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-black leading-none ${item.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                              {item.status === 'active' ? 'نشط' : 'معطّل'}
                            </span>
                            {item.maxUses !== undefined && item.maxUses !== null ? (
                              <span className="bg-emerald-100/50 text-emerald-800 px-2 py-0.5 rounded-full text-[9px] font-black">
                                حد الأجهزة: {item.usedCount || 0} / {item.maxUses}
                              </span>
                            ) : (
                              <span className="bg-purple-100/50 text-purple-850 px-2 py-0.5 rounded-full text-[9px] font-black">
                                أجهزة غير محدودة
                              </span>
                            )}
                            {item.expiresAt ? (
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black ${new Date(item.expiresAt).getTime() < Date.now() ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'}`}>
                                انتهاء: {new Date(item.expiresAt).toLocaleString('ar-SA')}
                              </span>
                            ) : (
                              <span className="bg-emerald-100/50 text-emerald-800 px-2 py-0.5 rounded-full text-[9px] font-black">
                                صلاحية دائمية
                              </span>
                            )}
                          </div>
                          {item.redemptions && item.redemptions.length > 0 && (
                            <div className="mt-2 bg-emerald-50/40 border border-emerald-100/50 rounded-2xl p-3 space-y-1.5 text-right">
                              <span className="block text-[10px] font-black text-emerald-800">الأجهزة المقترنة والمرتبطة بهذا الترخيص:</span>
                              <div className="space-y-1 max-h-[80px] overflow-y-auto">
                                {item.redemptions.map((red, rIdx) => (
                                  <div key={rIdx} className="flex flex-wrap items-center justify-between text-[9px] font-mono text-emerald-600 bg-white px-2 py-1 rounded-lg border border-emerald-50">
                                    <span>الـ IP: {red.ip}</span>
                                    <span>معرّف الجهاز: {red.deviceId?.substring(0, 10)}...</span>
                                    <span>{new Date(red.timestamp).toLocaleTimeString('ar-SA')}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center">
                          <button 
                            onClick={() => handleToggleCode(item.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${item.status === 'active' ? 'bg-amber-50 text-amber-700 hover:bg-amber-105' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-105'}`}
                          >
                            {item.status === 'active' ? 'تعطيل' : 'تفعيل'}
                          </button>
                          <button 
                            onClick={() => handleDeleteCode(item.id)}
                            className="p-2 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition"
                            title="حذف نهائياً"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Secures & free trials management panel */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-6">
              {/* Active Trials Panel */}
              <div className="bg-white rounded-[2rem] border border-emerald-100 shadow-xl shadow-emerald-200/40 overflow-hidden flex flex-col">
                <div className="p-6 border-b border-emerald-50 bg-emerald-50/20 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-emerald-950 text-base">الأجهزة المفعلة للتجربة ({trials.length})</h3>
                    <p className="text-[10px] text-emerald-500 font-semibold mt-0.5">قائمة بالأجهزة التي استلمت صلاحية مجانية لمدة 3 ساعات بنظام البصمة والموقع.</p>
                  </div>
                  <button 
                    onClick={fetchAdminTrialsAndLogs}
                    className="text-emerald-600 hover:text-emerald-700 text-xs font-bold flex items-center gap-1 bg-emerald-50/80 px-2.5 py-1.5 rounded-lg border border-emerald-100 hover:scale-[1.02] transition"
                  >
                    <RefreshCw className="w-3 h-3" /> تحديث الفترات
                  </button>
                </div>
                <div className="divide-y divide-emerald-50 max-h-[300px] overflow-y-auto flex-1">
                  {trials.length === 0 ? (
                    <div className="p-8 text-center text-emerald-300 font-bold text-xs">
                      لا توجد أجهزة نشطة في الفترة التجريبية حالياً.
                    </div>
                  ) : (
                    trials.map((trial) => (
                      <div key={trial.id} className="p-4 space-y-2">
                        <div className="flex items-center justify-between text-xs font-bold">
                          <span className="font-mono bg-emerald-50 text-emerald-950 px-2 py-1.5 rounded-lg truncate max-w-[170px]" title={trial.accessCode}>
                            كود: {trial.accessCode}
                          </span>
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[9px] font-black ${trial.status === 'active' ? 'bg-emerald-100 text-emerald-800 animate-pulse' : 'bg-slate-100 text-slate-800'}`}>
                            {trial.status === 'active' ? 'نشط (متبقي)' : 'منتهي الصلاحية'}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[10px] text-emerald-400 font-semibold leading-normal">
                          <div>
                            <span className="text-emerald-700">عنوان الـ IP:</span> {trial.ip}
                          </div>
                          <div className="truncate" title={trial.fingerprint}>
                            <span className="text-emerald-700">بصمة الجهاز:</span> {trial.fingerprint}
                          </div>
                          <div className="col-span-2">
                            <span className="text-emerald-700">تاريخ التفعيل:</span> {new Date(trial.createdAt).toLocaleString('ar-SA')}
                          </div>
                          <div className="col-span-2">
                            <span className="text-emerald-700">تاريخ انتهاء الصلاحية:</span> {new Date(trial.expiresAt).toLocaleString('ar-SA')}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Security Logs Panel */}
              <div className="bg-white rounded-[2rem] border border-emerald-100 shadow-xl shadow-emerald-200/40 overflow-hidden flex flex-col">
                <div className="p-6 border-b border-emerald-50 bg-emerald-50/20 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-rose-950 text-base">سجلات الحماية ومحاولات غسيل البصمات ({trialLogs.length})</h3>
                    <p className="text-[10px] text-rose-500 font-semibold mt-0.5">رصد تفصيلي لعمليات تفعيل الأكواد ومحاولات الاحتيال وتكرار التسجيل.</p>
                  </div>
                  <button 
                    onClick={fetchAdminTrialsAndLogs}
                    className="text-emerald-600 hover:text-emerald-700 text-xs font-bold flex items-center gap-1 bg-emerald-50/80 px-2.5 py-1.5 rounded-lg border border-emerald-100 hover:scale-[1.02] transition"
                  >
                    <RefreshCw className="w-3 h-3" /> تحديث السجلات
                  </button>
                </div>
                <div className="divide-y divide-emerald-50 max-h-[300px] overflow-y-auto flex-1 font-mono text-xs">
                  {trialLogs.length === 0 ? (
                    <div className="p-8 text-center text-rose-300 font-bold text-xs">
                      سجلات مكافحة الاحتيال تبدو نظيفة تماماً في الوقت الحالي.
                    </div>
                  ) : (
                    trialLogs.map((log, i) => (
                      <div key={i} className="p-4 space-y-1 bg-slate-50/40">
                        <div className="flex items-center justify-between text-[10px] font-bold">
                          <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-black uppercase ${
                            log.event === 'claim_success' ? 'bg-emerald-100 text-emerald-800' :
                            log.event === 'claim_failed_abuse' ? 'bg-amber-100 text-amber-800' :
                            'bg-rose-100 text-rose-800 animate-pulse'
                          }`}>
                            {log.event}
                          </span>
                          <span className="text-emerald-400 font-semibold">{new Date(log.timestamp).toLocaleTimeString('ar-SA')}</span>
                        </div>
                        <p className="text-[10px] font-black text-emerald-990 leading-relaxed text-right">{log.details}</p>
                        <div className="flex gap-4 text-[9px] text-emerald-400 font-medium">
                          <span>الـ IP: {log.ip}</span>
                          <span className="truncate max-w-[120px]" title={log.fingerprint}>FP: {log.fingerprint}</span>
                          <span className="truncate max-w-[120px]" title={log.deviceId}>Dev: {log.deviceId}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Invitation System Security & Redemption Audit Logs Panel */}
            <div className="bg-white rounded-[2rem] border border-emerald-100 shadow-xl shadow-emerald-200/40 overflow-hidden flex flex-col mt-6">
              <div className="p-6 border-b border-emerald-50 bg-emerald-50/20 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-emerald-950 text-base flex items-center gap-2">
                    <History className="w-5 h-5 text-emerald-600" />
                    سجل تدقيق عمليات الأكواد والتفعيلات الأمنية ({auditLogs.length})
                  </h3>
                  <p className="text-[10px] text-emerald-500 font-semibold mt-0.5">رصد آمن لجميع أطوار أكواد الدعوة والتحقق من الأجهزة المسجلة وعناوين الـ IP.</p>
                </div>
                <button 
                  onClick={fetchAdminCodes}
                  className="text-emerald-600 hover:text-emerald-700 text-xs font-bold flex items-center gap-1 bg-emerald-50/80 px-2.5 py-1.5 rounded-lg border border-emerald-100 hover:scale-[1.02] transition"
                >
                  <RefreshCw className="w-3 h-3" /> تحديث سجل التدقيق
                </button>
              </div>
              <div className="divide-y divide-emerald-50 max-h-[350px] overflow-y-auto font-mono text-xs">
                {auditLogs.length === 0 ? (
                  <div className="p-8 text-center text-emerald-300 font-bold text-xs">
                    سجل تدقيق الأكواد والدعوات فارغ تماماً حالياً.
                  </div>
                ) : (
                  auditLogs.map((log, i) => (
                    <div key={i} className="p-4 space-y-1 bg-emerald-50/10 hover:bg-emerald-50/25 transition">
                      <div className="flex items-center justify-between text-[10px] font-bold">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                          log.event === 'code_create' ? 'bg-purple-100 text-purple-800' :
                          log.event === 'login_redeem_success' ? 'bg-emerald-100 text-emerald-800' :
                          log.event === 'code_toggle' ? 'bg-amber-100 text-amber-800' :
                          log.event === 'code_revoke' ? 'bg-slate-100 text-slate-800' :
                          'bg-rose-100 text-rose-800'
                        }`}>
                          {log.event}
                        </span>
                        <span className="text-emerald-400 font-semibold">{new Date(log.timestamp).toLocaleString('ar-SA')}</span>
                      </div>
                      <p className="text-xs font-black text-emerald-950 leading-relaxed text-right mt-1">{log.details}</p>
                      <div className="flex gap-4 text-[9px] text-emerald-400 font-semibold mt-1">
                        <span>الـ IP: {log.ip}</span>
                        <span>الكود: {log.code}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        )}

        {/* Features Grid */}

        {/* Features Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
          {[
            { icon: Zap, title: 'Order Blocks', desc: 'تحديد مناطق تجميع وتصريف المؤسسات المالية.' },
            { icon: ShieldCheck, title: 'Liquidity Sweeps', desc: 'رصد عمليات سحب السيولة قبل الانعكاسات الكبرى.' },
            { icon: BarChart3, title: 'FVG Analysis', desc: 'استهداف الفجوات السعرية كمناطق جذب للسعر.' }
          ].map((feature, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-emerald-50 hover:border-emerald-200 transition-colors">
              <feature.icon className="w-8 h-8 text-emerald-600 mb-4" />
              <h4 className="font-bold text-lg mb-2">{feature.title}</h4>
              <p className="text-emerald-500 text-sm leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </section>
      </main>

      {/* Footer */}
      <footer className="max-w-4xl mx-auto px-6 py-12 border-t border-emerald-100 text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-emerald-800 font-bold">
          <TrendingUp className="w-5 h-5 text-emerald-600" />
          <span>سهم برو - ICT</span>
        </div>
        <p className="text-emerald-400 text-xs max-w-md mx-auto leading-relaxed">
          تنبيه: التداول بأسلوب ICT يتطلب فهماً عميقاً لحركة السعر. التوصيات هي لأغراض تعليمية وتوضيحية لمفاهيم الـ Smart Money.
        </p>
        <div className="text-emerald-300 text-[10px] font-medium">
          © 2026 سهم برو. جميع الحقوق محفوظة.
        </div>
      </footer>
    </div>
  );
}
